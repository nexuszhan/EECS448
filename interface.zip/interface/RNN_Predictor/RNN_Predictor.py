import torch
from captum.attr import LayerIntegratedGradients
from captum.attr import visualization as viz
from transformers import AutoTokenizer
from torch import nn
import spacy
import re
from collections import defaultdict
from transformers import AutoModel

BERT_MODEL = "roberta-base"

class RNNClassifier(nn.Module):

    def __init__(self, input_size, hidden_size, num_layers, shrink, dropout) -> None:
        super().__init__()
        self.rnn = nn.RNN(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True, dropout=dropout)
        
        self.fc1 = nn.Linear(num_layers*hidden_size,shrink)
        self.fc2 = nn.Linear(shrink,1)
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, input):
        b_size = input.size(dim=0)
        _, x = self.rnn(input)
        x = torch.reshape(x, (b_size, -1))
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.sigmoid(x)
        return x

class Our_Model(nn.Module):
    """ input: a dict with key "text", which should be a list contains all post text
                          key "interaction_feature" should be a list contains list ["score", "ups", "downs", "num_comments", "gilded"] of all posts
        output: 1 means antiwork, 0 means not
    """
    def __init__(self, rnn, base_model):
        super().__init__()
        self.RNN = rnn
        self.base_model = base_model
        self.device = torch.device("cpu")
     
    def forward(self, input_ids, masks, l_fs, i_fs):
        ts = torch.zeros((len(i_fs), 797)).to(self.device)
        b_f = self.base_model(input_ids = input_ids.to(self.device), attention_mask=masks.to(self.device))[0][:,0]
        l_fs = l_fs.to(self.device)
        i_fs = i_fs.to(self.device)
        ts = torch.unsqueeze(torch.cat((l_fs, i_fs, b_f), dim=-1),0)
        return self.RNN(ts)

class RNNpredict():
    def __init__(self):
        self.device = torch.device("cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(BERT_MODEL)
        self.base_model = AutoModel.from_pretrained("roberta-base")

    def post_Linguistic_feature(self, temp):
        pronoun1Regex = re.compile(r'\b(I|my|me|mine|(?-i:us))\b',re.I)
        pronoun12Regex = re.compile(r'\b(we|our|ours|(?-i:us))\b',re.I)
        pronoun2Regex = re.compile(r'\b(you|your|yours|(?-i:us))\b',re.I)
        pronoun3Regex = re.compile(r'\b(he|his|him|she|her|hers|(?-i:us))\b',re.I)
        pronoun32Regex = re.compile(r'\b(they|their|them|theirs|(?-i:us))\b',re.I)
        nlp = spacy.load("en_core_web_sm")

        length = len(temp)
        post_features = [length, len(pronoun1Regex.findall(temp)) / length, len(pronoun12Regex.findall(temp)) / length, len(pronoun2Regex.findall(temp)) / length, len(pronoun3Regex.findall(temp)) / length, len(pronoun32Regex.findall(temp)) / length]
        tokens = defaultdict(int)
        temp = nlp(temp)
        length = len(temp)
        for token in temp:
            tokens[token.pos_] += 1
        # print(tokens.keys())
        post_features.extend([tokens['NOUN'] / length, tokens['VERB'] / length, tokens['ADJ'] / length, tokens['ADV'] / length, tokens['ADP'] / length, tokens['CCONJ'] / length, tokens['NUM'] / length, tokens['PUNCT'] / length, tokens['PRON'] / length, tokens['AUX'] / length, tokens['DET'] / length, tokens['INTJ'] / length, tokens['PART'] / length, tokens['PROPN'] / length, tokens['SCONJ'] / length, tokens['SYM'] / length, tokens['X'] / length, tokens["SPACE"] / length])

        # if features is None:
        return torch.tensor(post_features)

    def prepare(self, texts, tokenizer):
        l = len(texts)
        masks = torch.zeros((l,1,512), dtype=torch.long)
        input_ids = torch.zeros((l,1,512), dtype=torch.long)
        l_fs = torch.zeros((l, 24), dtype=torch.long)
        for i, text in enumerate(texts):
            input = tokenizer(text, padding='max_length', max_length = 512, truncation=True, return_tensors="pt")
            masks[i] = input['attention_mask']
            input_ids[i] = input['input_ids'].squeeze(1)
            l_fs[i] = self.post_Linguistic_feature(text)
        return masks.squeeze(1), input_ids.squeeze(1), l_fs
    
    def len_tokens(self, ids, tokenizer):
        l = 0
        for id in ids.tolist():
            if id == tokenizer.eos_token_id:
                return l
            l += 1
    
    def run_model(self, posts, i_fs=None, show=False, true_class=None):
        """
        input arguments:
                posts: list of post texts of length num_posts
                i_fs: tensor of interaction features (None by default), length num_posts, each feature vector is tensor([#score, #ups, #downs, #num_comments, #gilded])
                show: set true if want to have a picture of attributions of each word
                true_class: if the posts have true label of 1/0 (antiwork/non-antiwork), can be provided for drawing
        outputs:
                attr_sentences: list of length num_posts, eath element is a list of word attributions
                sentences: list of length num_posts, each element is a list of words (corresponds to word attibution list)
        """
        rnn = RNNClassifier(input_size=797, hidden_size=128, num_layers=1, shrink=32, dropout=0.5)
        rnn = torch.load("RNN_Predictor/bert_rnn_128_1_32.pt", map_location=torch.device("cpu"))
        test_model = Our_Model(rnn, self.base_model).to(self.device)

        num_posts = len(posts)
        masks, input_ids, l_fs = self.prepare(posts, self.tokenizer)
        if i_fs is None:
            i_fs = torch.zeros((num_posts, 5))
        assert len(i_fs) == num_posts
        test_model.eval()
        result = test_model(input_ids, masks, l_fs, i_fs)

        base = torch.ones_like(input_ids)*self.tokenizer.pad_token_id
        for i in range(num_posts):
            base[i][0] = self.tokenizer.bos_token_id
            base[i][self.len_tokens(input_ids[i], self.tokenizer)] = self.tokenizer.eos_token_id
        test_model.train()
        layers = self.base_model.embeddings
        ig = LayerIntegratedGradients(test_model.forward, layers)
        attributions= ig.attribute(inputs=input_ids, baselines=base, method='gausslegendre', additional_forward_args=(masks, l_fs, i_fs), internal_batch_size=1)
        attr_sentencs = []
        sentences = []
        for j in range(num_posts):
            l = self.len_tokens(input_ids[j], self.tokenizer)
            scores = attributions[j].sum(dim=-1).squeeze(0)
            scores = scores[:l+1]
            scores = (scores-scores.mean()) / scores.norm()
            words = []
            for i, id in enumerate(input_ids[j, : l+1]):
                word = self.tokenizer.decode([id])
                words.append(word)
            if show:
                vis_data = viz.VisualizationDataRecord(
                    raw_input_ids=words,
                    word_attributions=scores,
                    pred_prob=result.squeeze(0).item(),
                    pred_class= 1 if result.squeeze(0).item()>0.5 else 0,
                    attr_class=None,                    true_class=true_class,
                    attr_score=attributions[j].sum(),
                    convergence_score=None
                )
                print(viz.visualize_text([vis_data], legend=False))
            attr_sentencs.append(scores.tolist())
            sentences.append(words)
            pred_class= 1 if result.squeeze(0).item()>0.5 else 0
        return attr_sentencs, sentences, pred_class
        
""" predictor = RNNPredict()
test_posts = [
    "They did NOT reset yearly.  So if you got sick once during those 60 days, then you got another occurrence, and the 60 days reset. So it pretty much ran on a principle of one step forward, two steps back. This also encouraged people to show up sick to not reset the clock",
    "We were required to be on the phones pretty much all the time, yet had to watch random training videos, answer emails, take surveys from corporate, etc",
    "We were also told to use the bathroom on the break",
    "We were required to make a sale on 25% of our calls, but we did not work in sales, we worked in insurance"
]
attr_sentences, sentences = predictor.run_model(test_posts, i_fs=None, show=False, true_class=1)
print(attr_sentences)
print(sentences)
print(len(sentences[0]))
print(len(attr_sentences[0])) """