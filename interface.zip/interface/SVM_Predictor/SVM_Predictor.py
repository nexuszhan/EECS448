import pickle
import nltk
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import svm
import numpy as np

def tokenize(text):
    tokens = nltk.word_tokenize(text)
    stems = []
    for item in tokens:
        stems.append(PorterStemmer().stem(item))
    return stems

def SVMpredict(input_texts):
    # INPUT: a list of post texts
    # OUTPUT: prediction, 0 for not antiwork, 1 for antiwork
    #         words that should be highlighted
    vectorizer = TfidfVectorizer(tokenizer=tokenize, stop_words='english')
    vectorizer = pickle.load(open("SVM_Predictor/tfidf.pickle", "rb"))
    model = svm.SVC(class_weight={0:1,1:1}, kernel='linear')
    model = pickle.load(open("SVM_Predictor/model.pickle", "rb"))

    response = vectorizer.transform(input_texts).toarray().sum(axis=0, keepdims=False)
    prediction = model.predict([response])[0]
    coefficient = model.coef_
    weights = (coefficient * response).reshape(-1)
    args = np.argsort(weights)
    indices = args[:10] if prediction==0 else args[-10:]
    tk = vectorizer.build_tokenizer()
    voc_dict = vectorizer.vocabulary_
    words = []
    for post in input_texts:
        for token in tk(post):
            if token in voc_dict and voc_dict[token] in indices:
                words.append(token)

    return prediction, words